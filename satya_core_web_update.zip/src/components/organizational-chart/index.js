export { default } from './organizational-chart';
