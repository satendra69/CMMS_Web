export { default as AboutView } from './about-view';
